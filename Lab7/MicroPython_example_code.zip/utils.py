# In this file you can place the functions you write for your robot
import math
from machine import Pin

def readIRSensors(analog_pins):
    '''
    Read the IR sensors using the AD converter and return a list with inverted values:
    white = 0; 4095 = black
    '''
    return [4095 - value.read() for value in analog_pins]


def get_wheels_speed(encoderValues, oldEncoderValues, PULSES_PER_TURN, delta_t):
    """Computes speed of the wheels based on encoder readings"""
    # Calculate the change in angular position of the wheels:
    ang_diff_l = 2*math.pi*(encoderValues[0] - oldEncoderValues[0])/PULSES_PER_TURN
    ang_diff_r = 2*math.pi*(encoderValues[1] - oldEncoderValues[1])/PULSES_PER_TURN

    # Calculate the angular speeds:
    wl = ang_diff_l/delta_t
    wr = ang_diff_r/delta_t

    return wl, wr

# Encoder class
class Encoder:
    def __init__(self, pin_a, pin_b):
        self.pin_a = pin_a
        self.pin_b = pin_b
        self._pos = 0
        self._state = 0
        self.a_interrupt = pin_a.irq(trigger=Pin.IRQ_RISING | Pin.IRQ_FALLING, handler=self.a_callback)
        self.b_interrupt = pin_b.irq(trigger=Pin.IRQ_RISING | Pin.IRQ_FALLING, handler=self.b_callback)

    def a_callback(self, pin):
        if self._state == 0 and pin():
            self._state = 1
            self._pos += 1
        elif self._state == 1 and not pin():
            self._state = 0
            self._pos -= 1
        elif self._state == 2 and not pin():
            self._state = 3
        elif self._state == 3 and pin():
            self._state = 2

    def b_callback(self, pin):
        if self._state == 0 and pin():
            self._state = 3
        elif self._state == 1 and pin():
            self._state = 2
        elif self._state == 2 and not pin():
            self._state = 1
        elif self._state == 3 and not pin():
            self._state = 0
            
    def position(self):
        return self._pos
    
    def reset(self):
        self._pos = 0
        self._state = 0
        

def test_motors(motor1, motor2, encoder1, encoder2):
    '''
    Sequence of movements to test the motors at different speeds and directions.
    '''
    from time import sleep

    print("\nLeft motor forward")
    for speed in range(100):
        print(encoder2.position(), encoder1.position())
        motor1.forward(speed)
        sleep(0.05)
    motor1.stop()
    sleep(1)

    print("\nLeft motor backward")
    for speed in range(100):
        print(encoder2.position(), encoder1.position())
        motor1.backwards(speed)
        sleep(0.05)
    motor1.stop()
    sleep(1)

    print("\nRight motor forward")
    for speed in range(100):
        print(encoder2.position(), encoder1.position())
        motor2.forward(speed)
        sleep(0.05)
    motor2.stop()
    sleep(1)

    print("\nRight motor backward")
    for speed in range(100):
        print(encoder2.position(), encoder1.position())
        motor2.backwards(speed)
        sleep(0.05)
    motor2.stop()
    sleep(1)
